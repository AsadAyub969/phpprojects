<?php

    include 'DatabaseConfig.php';
    if(
        isset($_POST["user_id"]) && 
        isset($_POST["delv_vehicle_type"]) && 
        isset($_POST["delv_vehicle_reg"]) && 
        isset($_POST["delv_vehicle_reg_img"]) && 
        isset($_POST["delv_contract_id"]) && 
        isset($_POST["delv_contract_img"]) && 
        isset($_POST["delv_elec_bill_img"]) && 
        isset($_POST["delv_pick_price"]) && 
        isset($_POST["delv_storage_price"]) && 
        isset($_POST["delv_return_cost"]) && 
        isset($_POST["delv_self_evaluation"]) &&
        isset($_POST["delv_review"])
        ){

        $con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName) or die('Unable To connect');

        $stmt = $con->prepare(
            "INSERT INTO delivery_man
            (user_id, delv_vehicle_type, delv_vehicle_reg,
            delv_vehicle_reg_img, delv_contract_id, delv_contract_img, 
            delv_elec_bill_img, delv_pick_price, delv_storage_price, 
            delv_return_cost, delv_self_evaluation, delv_review) 
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?)"   
        );


        

        $stmt->bind_param(
            "isisissiiiss", 
            $user_id, 
            $delv_vehicle_type, 
            $delv_vehicle_reg, 
            $delv_vehicle_reg_img, 
            $delv_contract_id, 
            $delv_contract_img, 
            $delv_elec_bill_img, 
            $delv_pick_price, 
            $delv_storage_price, 
            $delv_return_cost, 
            $delv_self_evaluation,
            $delv_review
        );

        $user_id= $_POST["user_id"];
        $delv_vehicle_type= $_POST["delv_vehicle_type"];
        $delv_vehicle_reg= $_POST["delv_vehicle_reg"];
        $delv_vehicle_reg_img= $_POST["delv_vehicle_reg_img"];
        $delv_contract_id= $_POST["delv_contract_id"];
        $delv_contract_img= $_POST["delv_contract_img"];
        $delv_elec_bill_img= $_POST["delv_elec_bill_img"];
        $delv_pick_price= $_POST["delv_pick_price"];
        $delv_storage_price= $_POST["delv_storage_price"];
        $delv_return_cost= $_POST["delv_return_cost"];
        $delv_self_evaluation=$_POST["delv_self_evaluation"];
        $delv_review =$_POST["delv_review"];

        $response = array();

        if($stmt->execute())
        {
            $response["success"] = "TRUE";
        }else{
            $response["success"] = "FALSE: DELIVERY MAN NOT INSERTED IN DATABASE";
        }

        echo json_encode($response);
    }else{
        $response = array();
        $response["success"] = "FALSE: INCONSISTENT INPUT";
        echo json_encode($response);
    }

?>