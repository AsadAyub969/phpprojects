<?php
include 'DatabaseConfig.php';
    $con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName) or die('Unable To connect');
    

        $statmt = $con->prepare("SELECT * FROM orders;");
        $statmt->execute();
        $result = $statmt->get_result();
        $response = array();

        if (mysqli_num_rows($result) > 0) {

            while($row = $result->fetch_assoc()) {
                array_push(
                    $response, 
                    array(
                        "order_id"=>$row["order_id"], 
                        "user_id"=>$row["user_id"], 
                        "order_title"=>$row["order_title"], 
                        "order_description"=>$row["order_description"],
                        "order_price"=>$row["order_price"],
                        "order_img_url_1"=>$row["order_img_url_1"],
                        "order_img_url_2"=>$row["order_img_url_2"]
                    )
                );
            }
            echo json_encode($response);
        } else {
            echo "Error: NO RECORD FOUND";
        }
?>



