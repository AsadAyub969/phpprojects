<?php

    include 'DatabaseConfig.php';
    if(
        isset($_POST["user_id"]) && 
        isset($_POST["seller_parentage"]) && 
        isset($_POST["seller_company_name"]) && 
        isset($_POST["seller_type_of_merchendise"]) && 
        isset($_POST["seller_target_cities"]) && 
        isset($_POST["seller_price_per_package"]) &&
        isset($_POST["seller_merch_desc"])
        ){
        
        $con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName) or die('Unable To connect');

        $stmt = $con->prepare(
            "INSERT INTO seller
            (user_id, seller_parentage, seller_company_name, 
            seller_type_of_merchendise, seller_target_cities, 
            seller_price_per_package, seller_merch_desc) 
            VALUES (?,?,?,?,?,?,?)"
        );

        
        $stmt->bind_param(
            "issssis", 
            $user_id ,
            $seller_parentage ,
            $seller_company_name ,
            $seller_type_of_merchendise ,
            $seller_target_cities ,
            $seller_price_per_package,
            $seller_merch_desc
        );

        $user_id = $_POST["user_id"];
        $seller_parentage = $_POST["seller_parentage"];
        $seller_company_name = $_POST["seller_company_name"];
        $seller_type_of_merchendise = $_POST["seller_type_of_merchendise"];
        $seller_target_cities = $_POST["seller_target_cities"];
        $seller_price_per_package = $_POST["seller_price_per_package"];
        $seller_merch_desc = $_POST["seller_merch_desc"];

        $response = array();

        if($stmt->execute())
        {
            $response["success"] = "TRUE";
        }else{
            $response["success"] = "FALSE: USER NOT INSERTED IN DATABASE";
        }

        echo json_encode($response);
    }else{
        $response = array();
        $response["success"] = "FALSE: INCONSISTENT INPUT";
        echo json_encode($response);
    }

?>