<?php
include 'DatabaseConfig.php';
if (count($_POST) > 0) {
    $con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName) or die('Unable To connect');

    $statmt = $con->prepare("SELECT * FROM users WHERE user_id = ? ;");
    $user_id = $_POST['user_id'];
    $statmt->bind_param("i", $user_id);
    $statmt->execute();
    $result = $statmt->get_result();

        $response = array();

        if (mysqli_num_rows($result) > 0) {
            while($row = $result->fetch_assoc()) {
                array_push(
                    $response, 
                    array(
                        "user_id"=>$row["user_id"], 
                        "user_name"=>$row["user_name"], 
                        "user_national_card"=>$row["user_national_card"],
                        "user_home_address"=>$row["user_home_address"],
                        "user_family_status"=>$row["user_family_status"],
                        "user_city"=>$row["user_city"],
                        "user_age"=>$row["user_age"],
                        "user_phone"=>$row["user_phone"],
                        "user_whatsapp_phone"=>$row["user_whatsapp_phone"],
                        "user_bank_name"=>$row["user_bank_name"],
                        "user_bank_ac_number"=>$row["user_bank_ac_number"],
                        "user_facebook_address"=>$row["user_facebook_address"],
                        "user_image"=>$row["user_image"]
                    )
                );
            }
            echo json_encode($response);
        } else {
            echo "Error: NO RECORD FOUND";
        }
}
else{
    echo "Error: invalid input";
}
?>