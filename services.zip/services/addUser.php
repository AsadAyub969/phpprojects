<?php

    include 'DatabaseConfig.php';
    if(
        isset($_POST["user_name"]) && 
        isset($_POST["user_national_card"]) && 
        isset($_POST["user_home_address"]) && 
        isset($_POST["user_family_status"]) && 
        isset($_POST["user_city"]) && 
        isset($_POST["user_age"]) && 
        isset($_POST["user_phone"]) && 
        isset($_POST["user_whatsapp_phone"]) && 
        isset($_POST["user_bank_name"]) && 
        isset($_POST["user_bank_ac_number"]) && 
        isset($_POST["user_facebook_address"]) && 
        isset($_POST["user_image"])
        ){
        
        $con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName) or die('Unable To connect');

        $stmt = $con->prepare(
            "INSERT INTO users
            (user_name, user_national_card, user_home_address, user_family_status, user_city, 
            user_age, user_phone, user_whatsapp_phone, user_bank_name, user_bank_ac_number, user_facebook_address, 
            user_image) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)"
        );
        $stmt->bind_param(
            "sisssiiisiss", 
            $user_name, 
            $user_national_card ,
            $user_home_address ,
            $user_family_status ,
            $user_city ,
            $user_age ,
            $user_phone ,
            $user_whatsapp_phone,
            $user_bank_name ,
            $user_bank_ac_number ,
            $user_facebook_address ,
            $user_image 
        );

        $user_name = $_POST["user_name"];
        $user_national_card = $_POST["user_national_card"];
        $user_home_address = $_POST["user_home_address"];
        $user_family_status = $_POST["user_family_status"];
        $user_city = $_POST["user_city"];
        $user_age =$_POST["user_age"];
        $user_phone =$_POST["user_phone"];
        $user_whatsapp_phone=$_POST["user_whatsapp_phone"];
        $user_bank_name =$_POST["user_bank_name"];
        $user_bank_ac_number =$_POST["user_bank_ac_number"];
        $user_facebook_address =$_POST["user_facebook_address"];
        $user_image = $_POST["user_image"];

        $response = array();

        if($stmt->execute())
        {
            $response["success"] = "TRUE";
        }else{
            $response["success"] = "FALSE: USER NOT INSERTED IN DATABASE";
        }

        echo json_encode($response);
    }else{
        $response = array();
        $response["success"] = "FALSE: INCONSISTENT INPUT";
        echo json_encode($response);
    }

?>