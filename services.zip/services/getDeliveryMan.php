<?php
include 'DatabaseConfig.php';
if (count($_POST) > 0) {
    $con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName) or die('Unable To connect');

    $statmt = $con->prepare("SELECT * FROM delivery_man WHERE user_id = ? ;");
    $user_id = $_POST['user_id'];
    $statmt->bind_param("i", $user_id);
    $statmt->execute();
    $result = $statmt->get_result();
    
        $response = array();

        if (mysqli_num_rows($result) > 0) {

            while($row = $result->fetch_assoc()) {
                array_push(
                    $response, 
                    array(
                        "deliv_id"=>$row["deliv_id"], 
                        "user_id"=>$row["user_id"], 
                        "deliv_vehicle_type"=>$row["deliv_vehicle_type"], 
                        "deliv_vehicle_reg"=>$row["deliv_vehicle_reg"],
                        "deliv_vheicle_reg_img"=>$row["deliv_vheicle_reg_img"],
                        "deliv_contract_id"=>$row["deliv_contract_id"],
                        "deliv_contract_id_img"=>$row["deliv_contract_id_img"],
                        "deliv_elec_bill_img"=>$row["deliv_elec_bill_img"],
                        "deliv_price_per_order"=>$row["deliv_price_per_order"],
                        "deliv_pick_price"=>$row["deliv_pick_price"],
                        "deliv_storage_price"=>$row["deliv_storage_price"],
                        "deliv_return_cost"=>$row["deliv_return_cost"],
                        "deliv_self_evaluation"=>$row["deliv_self_evaluation"],
                        "deliv_review"=>$row["deliv_review"]
                    )
                );
            }
            echo json_encode($response);
        } else {
            echo "Error: NO RECORD FOUND";
        }
}
else{
    echo "Error: invalid input";
}
?>