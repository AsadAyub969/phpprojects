<?php

    include 'DatabaseConfig.php';
    if(
        isset($_POST["user_id"]) && 
        isset($_POST["order_title"]) && 
        isset($_POST["order_description"]) && 
        isset($_POST["order_price"]) && 
        isset($_POST["order_img_url_1"]) && 
        isset($_POST["order_img_url_2"]) 
        ){
        
        $con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName) or die('Unable To connect');

        $stmt = $con->prepare(
            "INSERT INTO orders
            (user_id, order_title, order_description, order_price, 
            order_img_url_1, order_img_url_2 )
            VALUES (?,?,?,?,?,?)"
        );

        $stmt->bind_param(
            "ississ", 
            $user_id,
            $order_title,
            $order_description,
            $order_price,
            $order_img_url_1,
            $order_img_url_2
        );


        $user_id=$_POST["user_id"];
        $order_title=$_POST["order_title"];
        $order_description=$_POST["order_description"];
        $order_price=$_POST["order_price"];
        $order_img_url_1=$_POST["order_img_url_1"];
        $order_img_url_2=$_POST["order_img_url_2"];

        $response = array();

        if($stmt->execute())
        {
            $response["success"] = "TRUE";
        }else{
            
            $response["success"] = "FALSE: USER NOT INSERTED IN DATABASE";
        }

        echo json_encode($response);
    }else{
        $response = array();
        $response["success"] = "FALSE: INCONSISTENT INPUT";
        echo json_encode($response);
    }

?>