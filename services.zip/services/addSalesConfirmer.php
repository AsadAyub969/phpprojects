<?php

    include 'DatabaseConfig.php';
    if(
        isset($_POST["user_id"]) && 
        isset($_POST["sales_price_per_order"]) && 
        isset($_POST["sales_voice_recording"]) && 
        isset($_POST["sales_review"])
        ){

        $con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName) or die('Unable To connect');

        $stmt = $con->prepare(
            "INSERT INTO sales_confirmer
            (user_id, sales_price_per_order, 
            sales_voice_recording, sales_review)
            VALUES (?,?,?,?)"   
        );

        $stmt->bind_param(
            "iiss", 
            $user_id,
            $sales_price_per_order,
            $sales_voice_recording,
            $sales_review
        );

        $user_id = $_POST["user_id"];
        $sales_price_per_order = $_POST["sales_price_per_order"];
        $sales_voice_recording =$_POST["sales_voice_recording"];
        $sales_review=$_POST["sales_review"];

        $response = array();

        if($stmt->execute())
        {
            $response["success"] = "TRUE";
        }else{
            $response["success"] = "FALSE: USER NOT INSERTED IN DATABASE";
        }

        echo json_encode($response);
    }else{
        $response = array();
        $response["success"] = "FALSE: INCONSISTENT INPUT";
        echo json_encode($response);
    }

?>