<?php
include 'DatabaseConfig.php';
$message = "";
if (count($_POST) > 0) {
    $con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName) or die('Unable To connect');
    
    $statmt = $con->prepare("SELECT * FROM logins WHERE login_username= ? and login_password = ? ;");
    $username = $_POST['login_username'];
    $password = $_POST['login_password'];
    $password = md5($password);
    $statmt->bind_param("ss", $username, $password);
    $statmt->execute();
    $result = $statmt->get_result();
    
    $row  = $result->fetch_assoc();
    
    
    if (is_array($row)) {
        $arr = array(
            "login_id"=>$row["login_id"], 
            "login_username"=>$row["login_username"], 
            "login_password"=>$row["login_password"],
            "user_id"=>$row["user_id"]
        );
        echo json_encode($arr);
    } else {
        $message = "Invalid Username or Password!";
    }
    
}
?>



