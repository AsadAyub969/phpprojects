<?php
include 'DatabaseConfig.php';
if (count($_POST) > 0) {
    $con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName) or die('Unable To connect');
    
        $statmt = $con->prepare("SELECT * FROM seller WHERE user_id = ? ;");
        $user_id = $_POST['user_id'];
        $statmt->bind_param("i", $user_id);
        $statmt->execute();
        $result = $statmt->get_result();
        $response = array();

        if (mysqli_num_rows($result) > 0) {

            while($row = $result->fetch_assoc()) {
                array_push(
                    $response, 
                    array(
                        "seller_id"=>$row["seller_id"], 
                        "user_id"=>$row["user_id"], 
                        "seller_parentage"=>$row["seller_parentage"],
                        "seller_company_name"=>$row["seller_company_name"],
                        "seller_type_of_merchendise"=>$row["seller_type_of_merchendise"],
                        "seller_target_cities"=>$row["seller_target_cities"],
                        "seller_price_per_package"=>$row["seller_price_per_package"],
                        "seller_merch_desc"=>$row["seller_merch_desc"]
                    )
                );
            }
            echo json_encode($response);
        } else {
            echo "Error: NO RECORD FOUND";
        }
}
else{
    echo "Error: invalid input";
}
?>



