<?php
include 'DatabaseConfig.php';
if (count($_POST) > 0) {
    $con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName) or die('Unable To connect');
    

        $statmt = $con->prepare("SELECT * FROM sales_confirmer WHERE user_id = ? ;");
        $user_id = $_POST['user_id'];
        $statmt->bind_param("i", $user_id);
        $statmt->execute();
        $result = $statmt->get_result();
        $response = array();

        if (mysqli_num_rows($result) > 0) {

            while($row = $result->fetch_assoc()) {
                array_push(
                    $response, 
                    array(
                        "sales_id"=>$row["sales_id"], 
                        "user_id"=>$row["user_id"], 
                        "sales_price_per_order"=>$row["sales_price_per_order"], 
                        "sales_voice_recording"=>$row["sales_voice_recording"],
                        "sales_review"=>$row["sales_review"]
                    )
                );
            }
            echo json_encode($response);
        } else {
            echo "Error: NO RECORD FOUND";
        }
}
else{
    echo "Error: invalid input";
}
?>



